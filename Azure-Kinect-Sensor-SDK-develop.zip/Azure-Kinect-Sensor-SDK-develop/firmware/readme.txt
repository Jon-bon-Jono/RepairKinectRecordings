Removed beta moniker. Firmware now shipping on new Azure Kinect DKs

Firmware v1.6.110080014 Fixes:

Bug 2071218 - Sensor not detected with first boot on Jetson Nano
