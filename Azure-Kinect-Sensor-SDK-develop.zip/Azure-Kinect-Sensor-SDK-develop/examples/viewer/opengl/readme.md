A no-frills viewer tool that just shows the depth image and color images from the default camera.

This tools takes no additional input.