Enumerate_devices.exe lists all the devices connected to the system and displays each devices serial number. 
This sample illustrates how a user would open a device of a specific serial number.

This tools takes no additional input.