# Depth Engine Version (deversion)

This is a simple command line tool to determine the version of the Azure Kinect plugin
that is currently in the loader's path.

`deversion` will print out the version of the depth engine plugin it loads. If
`deversion` is unable to load a depth engine it will not print out a version.