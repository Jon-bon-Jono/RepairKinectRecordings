# Azure Kinect Fast Capture:trigger

## Introduction

The Azure Kinect Fast Capture trigger will send a command to the Azure Kinect Fast 
Capture streaming process to take a capture.
The Azure Kinect Fast Capture trigger requires that the Azure Kinect Fast Capture 
Streaming tool is already running.

## Usage Info

Run `fastcapture_trigger.exe` to take a capture.

Run `fastcapture_trigger.exe` to exit the streaming process.